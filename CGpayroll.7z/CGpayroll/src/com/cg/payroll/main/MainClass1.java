package com.cg.payroll.main;

import com.cg.payroll.beans.Associate1;

public class MainClass1 {

	public static void main(String[] args) {
		int associateIdToBeSearch=111;
		Associate1 associate = searchAssociate(associateIdToBeSearch);
		if(associate!=null)
			System.out.println(associate.getDesignation());
		else
			System.out.println("associate details with Id "+associateIdToBeSearch+" is not found");
	}
	public static Associate1 searchAssociate(int associateIdToBeSearch){
		Associate1[]associates = new Associate1[4];
		associates[0]=new Associate1(111, 125, "pavan"," kalyan", "ece"," se"," gsdgh", "ghdsf");
		associates[1]=new Associate1(121, 125, "npavan"," kalyan", "eee"," se"," gsdgh", "ghdsf");
		for(Associate1 associate : associates){
			if(associate!=null&&associate.getAssociateId()==associateIdToBeSearch)
				return associate;
		}
		return null;
		
	}
	

}
